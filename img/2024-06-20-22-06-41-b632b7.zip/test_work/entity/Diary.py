# -*- coding: utf-8 -*-
# @Author: Dream fish
# @File: Diary.py
# @Time: 2024/6/18 14:03

class Diary:
    mood_dict = {
        "happy": 0,
        "sad": 2,
        "normal": 1
    }
    def __init__(self, title= None,weather= None, mood= None, content= None):
        self.title = title
        if mood in Diary.mood_dict:
            self.mood = Diary.mood_dict[mood]
        else:
            self.mood = None
        self.weather = weather
        self.content = content

    def __str__(self):
        return f"title: {self.title}, mood: {self.mood}, weather: {self.weather}, content: {self.content}"