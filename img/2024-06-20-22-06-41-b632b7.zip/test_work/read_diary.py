# -*- coding: utf-8 -*-
# @Author: Dream fish
# @File: read_diary.py
# @Time: 2024/6/20 11:02
from selenium import webdriver
import time
from item_process.login_item import login
from item_process.read_diary_item import read_diary

def read_diary_test():
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")  # 最大化窗口
    chrome = webdriver.Chrome(options=options)

    # 登录
    login(chrome, "root", "yx198973")

    # 读取日记
    time.sleep(6)
    read_diary(chrome, "关于系统")
    time.sleep(6)
    print("读取成功")