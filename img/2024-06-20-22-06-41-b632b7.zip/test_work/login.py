# -*- coding: utf-8 -*-
from selenium import webdriver
import os


from item_process import login_item as login

from entity.Data import DataLoader
def login_test():
    loader = DataLoader()
    diary = loader.get_data(os.path.abspath("./data/user_data.csv"))
    for i in diary:
        options = webdriver.ChromeOptions()
        options.add_argument("--start-maximized")  # 最大化窗口
        chrome = webdriver.Chrome(options=options)
        # 登录
        login.login(chrome, i[0], i[1])
        if chrome.title == "home":
            print("登录成功\tuserName: {},password: {}".format(i[0], i[1]))
        else:
            print("登录失败\tuserName: {},password: {}".format(i[0], i[1]))
        chrome.quit()

