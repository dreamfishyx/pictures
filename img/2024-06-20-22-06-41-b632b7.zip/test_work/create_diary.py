# -*- coding: utf-8 -*-
# @Author: Dream fish
# @File: create_diary.py
# @Time: 2024/6/20 9:39
from selenium import webdriver

from entity.Diary import Diary
from entity.Data import DataLoader
from item_process.login_item import login
from item_process.create_daily_item import create_daily
import os

def create_diary_test():
    loader = DataLoader()
    diaries = loader.get_data(os.path.abspath("./data/diary_data.csv"))
    # print(diaries)
    for i in diaries:
        diary = Diary(*i)
        options = webdriver.ChromeOptions()
        options.add_argument("--start-maximized")  # 最大化窗口
        chrome = webdriver.Chrome(options=options)
        # 登录
        login(chrome,"root" , "yx198973")
        # 创建日记

        # 判断是否查找成功
        if create_daily(chrome,diary):
            print("创建成功:{}".format(diary))
        else:
            print("创建失败:{}".format(diary))


