# -*- coding: utf-8 -*-
# @Author: Dream fish
# @File: delete_diary.py
# @Time: 2024/6/20 11:09

from selenium import webdriver
import time
from item_process.login_item import login
from item_process.delete_diary_item import delete_diary

def delete_diary_test():
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")  # 最大化窗口
    chrome = webdriver.Chrome(options=options)
    # 登录
    login(chrome,"root", "yx198973")
    #读取日记
    time.sleep(6)
    delete_diary(chrome,"删除测试")
    time.sleep(6)
    print("删除成功")