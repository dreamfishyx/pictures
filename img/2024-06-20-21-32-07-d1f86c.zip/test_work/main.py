import login
import delete_diary
import read_diary
import create_diary

if __name__ == '__main__':
    print("=========================登录测试:=========================")
    login.login_test()
    print("========================创建日记测试:========================")
    create_diary.create_diary_test()
    print("========================读取日记测试:========================")
    read_diary.read_diary_test()
    print("========================删除日记测试:========================")
    delete_diary.delete_diary_test()