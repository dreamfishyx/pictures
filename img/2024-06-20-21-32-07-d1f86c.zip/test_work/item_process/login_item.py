# -*- coding: utf-8 -*-
# @Author: Dream fish
# @File: login_item.py
# @Time: 2024/6/18 9:37

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC # 等待条件
import time



def login(browser:webdriver.Chrome,username: str, password: str):

    # 打开网页
    browser.get("http://localhost:8080/login")

    # 输入账号
    browser.find_element(By.ID, "userName").send_keys(username)

    # 输入密码
    browser.find_element(By.ID, "password").send_keys(password)

    # time.sleep(5)
    # 点击登录、等待元素加载
    wait = WebDriverWait(browser, 5)
    login_button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "div.but_div > button[type='submit']")))

    # 点击按钮
    login_button.click()


