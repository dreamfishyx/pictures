# -*- coding: utf-8 -*-
# @Author: Dream fish
# @File: read_diary_item.py
# @Time: 2024/6/18 11:26
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

def read_diary(chrome,title:str):
    # 点击日记
    time.sleep(5)
    diary_links = chrome.find_elements(By.CSS_SELECTOR, "div[class='item'] a[class='item_link']")
    # print(len(diary_links))
    for diary_link in diary_links:
        print(title)
        if diary_link.text == title:
            diary_link.click()
            return True
    return False
