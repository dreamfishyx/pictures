# -*- coding: utf-8 -*-
# @Author: Dream fish
# @File: logout_item.py
# @Time: 2024/6/18 19:00
import time
from selenium.webdriver.common.by import By

def logout(chrome):
    chrome.find_element(By.CSS_SELECTOR,"a[href='/user/logout']").click()
    time.sleep(10)
