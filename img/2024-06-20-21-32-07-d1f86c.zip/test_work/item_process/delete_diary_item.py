# -*- coding: utf-8 -*-
# @Author: Dream fish
# @File: delete_diary_item.py
# @Time: 2024/6/18 18:49
from selenium.webdriver.common.by import By
import time
def delete_diary(chrome,title:str):
    # 点击日记
    terms = chrome.find_elements(By.CSS_SELECTOR, "div[class='item']")
    # print(len(diary_links))
    for term in terms:
        diary_link = term.find_element(By.CSS_SELECTOR, "a[class='item_link']")
        # print(diary_link.text)
        if diary_link.text == title:
            # print(diary_link.text)
            term.find_element(By.CSS_SELECTOR, "a[class='del_link']").click()
            break

    time.sleep(8)
