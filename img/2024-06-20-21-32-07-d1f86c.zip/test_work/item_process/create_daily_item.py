# -*- coding: utf-8 -*-
# @Author: Dream fish
# @File: create_daily_item.py
# @Time: 2024/6/18 11:25
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC  # 等待条件
import time

from entity.Diary import Diary


def create_daily(chrome: webdriver.Chrome, diary: Diary):
    # time.sleep(5)

    # 点击创建日记
    wait = WebDriverWait(chrome, 10)
    plus_link = wait.until(EC.element_to_be_clickable((By.XPATH, '/html/body/div[1]/div[1]/span/a')))
    plus_link.click()

    # 输入标题
    chrome.find_element(By.CSS_SELECTOR, "input[name='title']").send_keys(diary.title)
    # time.sleep(3)

    # print(diary.weather)
    chrome.find_element(By.CSS_SELECTOR, "input[name='weather']").send_keys(diary.weather)
    # time.sleep(3)
    if diary.mood is not None:
        radio = f'input[type="radio"][value="{diary.mood}"]'
        radio_button = chrome.find_element(By.CSS_SELECTOR, radio)
        radio_button.click()
        # time.sleep(5)

    #无法修改编辑器内容,直接覆盖后重新渲染解析markdown
    # deitor_div = chrome.find_element(By.ID, "editor")
    script = """
       var element = document.getElementById('editor');
       element.innerHTML = "<textarea id='content' name='content' style='display:none;' placeholder='md'></textarea>";
       """

    chrome.execute_script(script)

    script = f"""
    var longStr = arguments[0];
    var element = document.getElementById('content');
    element.value = longStr;
    """
    chrome.execute_script(script, diary.content)

    "重新渲染解析markdown"
    chrome.execute_script("""
       editor = editormd("editor", {
            width: "96%",
            height: 1100,
            emoji: true,
            theme: "3024-day",
            previewTheme: "3024-day",
            editorTheme: "3024-day",
            editorFontSize: "14px",
            syncScrolling: "single",
            codeFold: true,
            flowChart: true, 
            sequenceDiagram: true, 
            searchReplace: true,
            dialogMaskOpacity: 0.1,   
            path: "/lib/editormd/lib/", 
            imageUpload: true, 
            imageFormats: ["jpg", "jpeg", "gif", "png", "bmp", "webp"],
            imageUploadURL: "/upload-image", 
        });
    """)
    # time.sleep(5)
    try:
        # 点击发布
        publish_button = chrome.find_element(By.ID, "save")
        publish_button.click()
        # time.sleep(3)

        # 确认
        WebDriverWait(chrome, 30, 0.5).until(EC.alert_is_present())
        alert = chrome.switch_to.alert
        ans = alert.text == "保存成功" if True else  False
        alert.accept()
        # time.sleep(3)
    except Exception as e:
        return False

    return ans
