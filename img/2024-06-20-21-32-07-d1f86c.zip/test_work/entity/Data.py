# -*- coding: utf-8 -*-
# @Author: Dream fish
# @File: Data.py
# @Time: 2024/6/19 11:28
import csv


class DataLoader:
    def get_data(self,file_path):
        file = open(file_path, "r", encoding='UTF-8')
        items = csv.reader(file)
        return list(items)
